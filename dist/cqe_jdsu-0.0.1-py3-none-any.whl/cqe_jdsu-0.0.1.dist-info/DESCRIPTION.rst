################################################################################
#                                                                              #
#   ontRemote.py                                                              #
#                                                                              #
#   Python interface to the new line of JDSU products                          #
#                                                                              #
#   Copyright (c) 2015 - 2019, VIAVI Solutions Inc.                             #
#                                                                              #
#   The contents of this file should not be copied or distributed              #
#   without permission being granted by VIAVI Solutions Inc.                   #
#                                                                              #
#   All rights reserved.                                                       #
#                                                                              #
################################################################################


